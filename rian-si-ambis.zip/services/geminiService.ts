import { GoogleGenAI, Type } from "@google/genai";
import { Task, TaskStatus } from '../types';

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Parses a "brain dump" string into structured tasks using Gemini.
 */
export const generateTasksFromBrainDump = async (brainDump: string): Promise<string[]> => {
  if (!brainDump.trim()) return [];

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Extract a list of actionable tasks from this text. Keep them concise. Text: "${brainDump}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tasks: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const jsonStr = response.text;
    if (!jsonStr) return [];
    
    const parsed = JSON.parse(jsonStr);
    return parsed.tasks || [];
  } catch (error) {
    console.error("Gemini Task Generation Error:", error);
    return ["Gagal memproses otomatis. Silakan input manual."];
  }
};

/**
 * Generates a motivational summary based on completed tasks with "Mamak" persona.
 */
export const generateDailyReview = async (tasks: Task[], notes: string, achievements: string = ''): Promise<string> => {
  const completed = tasks.filter(t => t.status === TaskStatus.DONE).map(t => t.title);
  const pending = tasks.filter(t => t.status !== TaskStatus.DONE).map(t => t.title);
  const total = tasks.length;
  const doneCount = completed.length;

  const prompt = `
    Role: Kamu adalah seorang IBU (Mamak) Indonesia yang sangat peduli pendidikan anaknya.
    User Profile: Anakmu adalah mahasiswa baru (Maba) di Politeknik Negeri Batam (Polibatam), jurusan Teknik Informatika.
    
    Context: Anakmu baru saja menyelesaikan harinya dan melaporkan kegiatannya kepadamu.
    
    Stats:
    - Selesai: ${doneCount} dari ${total} tugas.
    - Yang diselesaikan: ${completed.join(', ') || 'Tidak ada'}.
    - Yang BELUM selesai: ${pending.join(', ') || 'Tidak ada'}.
    - Curhat Anak: "${notes}".
    - PENCAPAIAN/KEBANGGAAN HARI INI: "${achievements}".

    Instruksi Gaya Bicara (PENTING):
    1. Gunakan bahasa Indonesia sehari-hari yang luwes, khas ibu-ibu yang cerewet tapi sayang.
    2. Panggil dia "Nak" atau "Anakku".
    
    Kondisi Respon:
    KONDISI 1: Jika ada pencapaian (Achievements terisi) atau semua tugas selesai:
    - Apresiasi pencapaiannya! Hubungkan dengan masa depan karirnya nanti.
    - Bilang Mamak bangga.
    
    KONDISI 2: Jika masih ada tugas yang BELUM selesai (Pending > 0) dan tidak ada pencapaian berarti:
    - MARAHI DIA. Omelin dia. Ingatkan kalau kuliah IT di Polibatam itu susah, jangan malas-malasan.
    - Ingatkan dia soal UKT mahal atau masa depan coding yang keras.

    KONDISI 3: Jika tidak ada tugas sama sekali:
    - Tanya kenapa nganggur? Suruh belajar coding atau baca modul.
    
    Output: Maksimal 4 kalimat. Emosional (Marah atau Bangga).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Mamak lagi sibuk masak, pokoknya selesaikan tugasmu!";
  } catch (error) {
    console.error("Gemini Review Error:", error);
    return "Mamak belum bisa angkat telepon (AI Error).";
  }
};