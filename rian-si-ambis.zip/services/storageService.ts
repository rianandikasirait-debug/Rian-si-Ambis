import { DailyEntry } from '../types';

const STORAGE_KEY = 'rian_si_ambis_data';

export const getEntries = (): DailyEntry[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Failed to load data", error);
    return [];
  }
};

export const saveEntry = (entry: DailyEntry): void => {
  let entries = getEntries();
  const existingIndex = entries.findIndex(e => e.id === entry.id);
  
  if (existingIndex >= 0) {
    entries[existingIndex] = entry;
  } else {
    entries.push(entry); // Add new
  }
  
  // Sort by date descending (Future dates first, then today, then past)
  entries.sort((a, b) => {
    if (a.date === b.date) return 0;
    return a.date < b.date ? 1 : -1;
  });
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
};

export const deleteEntry = (id: string): void => {
  const entries = getEntries();
  const newEntries = entries.filter(e => e.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(newEntries));
};

export const getEntryById = (id: string): DailyEntry | undefined => {
  const entries = getEntries();
  return entries.find(e => e.id === id);
};