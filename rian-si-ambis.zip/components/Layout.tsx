import React from 'react';
import { BookOpen, User } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center cursor-pointer" onClick={() => window.location.hash = ''}>
              <div className="bg-primary text-white p-2 rounded-lg mr-3">
                <BookOpen size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                  Rian si Ambis
                </h1>
                <p className="text-xs text-slate-500 font-medium">Daily Productivity Journal</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
               <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600">
                 <User size={16} />
               </div>
            </div>
          </div>
        </div>
      </nav>
      <main className="flex-grow w-full max-w-3xl mx-auto px-4 py-6 sm:px-6">
        {children}
      </main>
      <footer className="py-6 text-center text-slate-400 text-sm">
        &copy; {new Date().getFullYear()} Rian si Ambis. Keep Grinding.
      </footer>
    </div>
  );
};