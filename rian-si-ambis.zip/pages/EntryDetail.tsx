import React, { useEffect, useState, useRef } from 'react';
import { ArrowLeft, Save, Trash2, Wand2, Plus, Check, BrainCircuit, Loader2, Calendar, Image as ImageIcon, X, Camera, Phone, Mic, PhoneOff, Trophy, MicOff } from 'lucide-react';
import { DailyEntry, Task, TaskStatus, Mood, MOOD_EMOJIS, MOOD_LABELS } from '../types';
import { getEntryById, saveEntry, deleteEntry } from '../services/storageService';
import { generateTasksFromBrainDump, generateDailyReview } from '../services/geminiService';
import { useNavigate } from '../App';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

interface EntryDetailProps {
  id: string;
  initialDate?: string;
  isNew?: boolean;
}

// Helper functions for Audio Encoding/Decoding for Live API
function createBlob(data: Float32Array): { data: string; mimeType: string } {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  let binary = '';
  const bytes = new Uint8Array(int16.buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return {
    data: btoa(binary),
    mimeType: 'audio/pcm;rate=16000',
  };
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const EntryDetail: React.FC<EntryDetailProps> = ({ id, initialDate, isNew }) => {
  const { navigate } = useNavigate();
  const [loadingAI, setLoadingAI] = useState(false);
  const [brainDump, setBrainDump] = useState('');
  const [showBrainDump, setShowBrainDump] = useState(false);
  
  // Camera & Image State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Live Call State
  const [isCalling, setIsCalling] = useState(false);
  const [callStatus, setCallStatus] = useState<'connecting' | 'connected' | 'ended'>('ended');
  const [volumeLevel, setVolumeLevel] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const isMutedRef = useRef(false); // Ref for immediate access inside audio callbacks

  const liveSessionRef = useRef<any>(null); // To store session promise/control
  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);
  
  const [entry, setEntry] = useState<DailyEntry>({
    id: id,
    date: initialDate || new Date().toISOString().split('T')[0],
    tasks: [],
    notes: '',
    achievements: '',
    mood: Mood.NEUTRAL,
    aiSummary: '',
    imageUrl: ''
  });

  // Calculate if this entry is in the future
  const today = new Date().toISOString().split('T')[0];
  const isFuture = entry.date > today;

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isNew) {
      const existing = getEntryById(id);
      if (existing) setEntry(existing);
    }

    // Cleanup camera & audio on unmount
    return () => {
      stopCamera();
      endCall();
    };
  }, [id, isNew]);

  const toggleMute = () => {
    const newState = !isMuted;
    setIsMuted(newState);
    isMutedRef.current = newState;
  };

  // --- Live API Call Logic ---
  const startCall = async () => {
    setIsCalling(true);
    setCallStatus('connecting');
    setIsMuted(false);
    isMutedRef.current = false;

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Setup Audio Contexts
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = { input: inputCtx, output: outputCtx };
      
      const inputNode = inputCtx.createGain();
      const outputNode = outputCtx.createGain();
      outputNode.connect(outputCtx.destination); // Connect output to speakers

      // Get Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Prepare System Instruction based on current entry state
      const completed = entry.tasks.filter(t => t.status === TaskStatus.DONE).map(t => t.title).join(', ');
      const pending = entry.tasks.filter(t => t.status !== TaskStatus.DONE).map(t => t.title).join(', ');
      
      const systemInstruction = `
        You are "Mamak", a typical Indonesian/Batak mother whose child is a student at Polibatam (Teknik Informatika).
        Your child is calling you to report about their day.
        
        Current Data:
        - Date: ${entry.date}
        - Tasks Done: ${completed || 'None'}
        - Tasks Pending: ${pending || 'None'}
        - Notes/Curhat: ${entry.notes || 'None'}
        - Achievements: ${entry.achievements || 'None'}
        - Mood: ${entry.mood}

        Personality:
        - Speak in Indonesian with a motherly, slightly strict but loving tone.
        - If they have pending tasks, SCOLD them lovingly (remind them about expensive tuition/UKT).
        - If they have achievements or finished tasks, PRAISE them highly.
        - Be interactive. Listen to them.
        - Keep responses relatively short and conversational (speech).
      `;

      // Connect to Live API
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }, // Kore sounds a bit mature/motherly
          },
          systemInstruction: systemInstruction,
        },
        callbacks: {
          onopen: () => {
            setCallStatus('connected');
            // Connect Mic to Processor
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              // Check mute state from REF to avoid closure staleness
              if (isMutedRef.current) {
                setVolumeLevel(0);
                return;
              }

              const inputData = e.inputBuffer.getChannelData(0);
              
              // Visualizer volume calculation
              let sum = 0;
              for(let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
              setVolumeLevel(Math.sqrt(sum / inputData.length) * 100);

              const pcmBlob = createBlob(inputData);
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
             const base64Audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
             if (base64Audio) {
               if (outputCtx.state === 'suspended') await outputCtx.resume();
               
               nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
               
               const audioBuffer = await decodeAudioData(
                 decode(base64Audio),
                 outputCtx,
                 24000,
                 1
               );
               
               const source = outputCtx.createBufferSource();
               source.buffer = audioBuffer;
               source.connect(outputNode);
               source.addEventListener('ended', () => {
                 audioSourcesRef.current.delete(source);
               });
               
               source.start(nextStartTimeRef.current);
               nextStartTimeRef.current += audioBuffer.duration;
               audioSourcesRef.current.add(source);
             }
          },
          onclose: () => {
            setCallStatus('ended');
            setIsCalling(false);
          },
          onerror: (e) => {
            console.error("Live API Error", e);
            alert("Putus sambungan sama Mamak. Sinyal jelek kali.");
            endCall();
          }
        }
      });
      
      liveSessionRef.current = sessionPromise;

    } catch (error) {
      console.error("Failed to start call", error);
      setCallStatus('ended');
      setIsCalling(false);
      alert("Gagal nelpon Mamak. Cek mikrofon atau internet.");
    }
  };

  const endCall = () => {
    // Close audio contexts
    if (audioContextRef.current) {
      audioContextRef.current.input.close();
      audioContextRef.current.output.close();
    }
    
    // Stop all playing sources
    audioSourcesRef.current.forEach(s => s.stop());
    audioSourcesRef.current.clear();

    setIsCalling(false);
    setCallStatus('ended');
    setVolumeLevel(0);
    // Note: session.close() isn't strictly available on the promise wrapper in this pattern easily without storing the resolved session, 
    // but closing the context and stopping the script processor (via logic above effectively) kills the flow.
    // In a full implementation, we'd store the resolved session to call .close().
  };

  // --- End Live API Logic ---

  const startCamera = async () => {
    try {
      setIsCameraOpen(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Gagal membuka kamera:", err);
      alert("Gagal membuka kamera. Pastikan izin kamera sudah diberikan di browser.");
      setIsCameraOpen(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraOpen(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(-1, 1);
        ctx.drawImage(videoRef.current, -canvas.width, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setEntry(prev => ({ ...prev, imageUrl: dataUrl }));
        stopCamera();
      }
    }
  };

  const handleSave = () => {
    saveEntry(entry);
    navigate('');
  };

  const handleDelete = () => {
    if (confirm('Yakin mau hapus catatan ini? Nanti Mamak marah loh data hilang.')) {
      deleteEntry(id);
      navigate('');
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024 * 2) { 
        alert("Waduh Nak, fotonya kegedean (Max 2MB). Mamak susah nyimpannya.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEntry(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setEntry(prev => ({ ...prev, imageUrl: undefined }));
  };

  const addTask = (title: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      title,
      status: TaskStatus.TODO
    };
    setEntry(prev => ({ ...prev, tasks: [...prev.tasks, newTask] }));
  };

  const toggleTaskStatus = (taskId: string) => {
    setEntry(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => {
        if (t.id !== taskId) return t;
        const nextStatus = t.status === TaskStatus.TODO ? TaskStatus.DONE : TaskStatus.TODO;
        return { ...t, status: nextStatus };
      })
    }));
  };

  const removeTask = (taskId: string) => {
    setEntry(prev => ({
      ...prev,
      tasks: prev.tasks.filter(t => t.id !== taskId)
    }));
  };

  const handleMagicPlan = async () => {
    if (!brainDump.trim()) return;
    setLoadingAI(true);
    const newTasks = await generateTasksFromBrainDump(brainDump);
    const tasksObjects: Task[] = newTasks.map(t => ({
      id: crypto.randomUUID(),
      title: t,
      status: TaskStatus.TODO
    }));
    setEntry(prev => ({ ...prev, tasks: [...prev.tasks, ...tasksObjects] }));
    setBrainDump('');
    setShowBrainDump(false);
    setLoadingAI(false);
  };

  const handleMagicReview = async () => {
    setLoadingAI(true);
    const review = await generateDailyReview(entry.tasks, entry.notes, entry.achievements);
    setEntry(prev => ({ ...prev, aiSummary: review }));
    setLoadingAI(false);
    saveEntry({ ...entry, aiSummary: review });
  };

  return (
    <div className="space-y-6 pb-20 relative">
      
      {/* Phone Call Overlay */}
      {isCalling && (
        <div className="fixed inset-0 z-[100] bg-slate-900 flex flex-col items-center justify-between py-12 px-6 animate-in fade-in duration-300">
          <div className="text-center space-y-4 mt-10">
            <div className="w-32 h-32 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full mx-auto flex items-center justify-center relative shadow-2xl shadow-indigo-500/20">
              <span className="text-4xl">👩‍🦳</span>
              {callStatus === 'connected' && (
                <div className="absolute inset-0 rounded-full border-4 border-white/20 animate-ping"></div>
              )}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Mamak (Polibatam)</h2>
              <p className="text-indigo-200 animate-pulse">
                {callStatus === 'connecting' ? 'Menghubungkan...' : 'Sedang nelpon...'}
              </p>
            </div>
          </div>

          <div className="w-full max-w-xs h-32 flex items-center justify-center gap-1">
             {/* Simple Audio Visualizer based on volume */}
             {isMuted ? (
                <div className="text-slate-500 flex items-center gap-2">
                  <MicOff size={20} /> Mikrofon Mati
                </div>
             ) : (
                [...Array(5)].map((_, i) => (
                  <div 
                      key={i} 
                      className="w-3 bg-white/80 rounded-full transition-all duration-75"
                      style={{ height: `${20 + (volumeLevel * (i % 2 === 0 ? 2 : 1.5)) * Math.random() * 20}px` }}
                  ></div>
                ))
             )}
          </div>

          <div className="flex items-center gap-6">
            <button 
              onClick={toggleMute}
              className={`p-4 rounded-full transition-all ${isMuted ? 'bg-white text-slate-900' : 'bg-white/20 text-white hover:bg-white/30'}`}
            >
              {isMuted ? <MicOff size={28} /> : <Mic size={28} />}
            </button>
            
            <button 
              onClick={endCall}
              className="bg-red-500 hover:bg-red-600 text-white rounded-full p-6 shadow-xl shadow-red-500/30 transition-transform active:scale-95"
            >
              <PhoneOff size={32} />
            </button>
          </div>
        </div>
      )}

      {/* Navbar Actions */}
      <div className="flex items-center justify-between sticky top-16 bg-slate-50/90 backdrop-blur-sm py-2 z-40">
        <button onClick={() => navigate('')} className="text-slate-500 hover:text-slate-800 p-2">
          <ArrowLeft size={24} />
        </button>
        <div className="flex gap-2">
          {!isNew && (
            <button onClick={handleDelete} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg">
              <Trash2 size={20} />
            </button>
          )}
          <button 
            onClick={handleSave}
            className="bg-primary text-white px-4 py-2 rounded-lg font-medium shadow-md shadow-indigo-200 active:scale-95 transition-transform flex items-center gap-2"
          >
            <Save size={18} /> Simpan
          </button>
        </div>
      </div>

      {/* Date, Mood & Photo Section */}
      <div className={`p-5 rounded-2xl border shadow-sm space-y-4 transition-colors ${isFuture ? 'bg-indigo-50 border-indigo-100' : 'bg-white border-slate-100'}`}>
        <div>
          <label className={`block text-xs font-bold uppercase tracking-wider mb-1 ${isFuture ? 'text-indigo-400' : 'text-slate-400'}`}>
            {isFuture ? 'Target Tanggal' : 'Tanggal Jurnal'}
          </label>
          <div className="flex items-center gap-2">
            <Calendar size={20} className={isFuture ? "text-indigo-500" : "text-slate-400"} />
            <input 
              type="date" 
              value={entry.date}
              onChange={(e) => setEntry({...entry, date: e.target.value})}
              className="w-full text-lg font-bold text-slate-800 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-primary focus:outline-none py-1 transition-all"
            />
          </div>
        </div>

        {/* Image Upload / Camera Area */}
        <div className="animate-in fade-in">
          {entry.imageUrl ? (
            <div className="relative group rounded-xl overflow-hidden border border-slate-200 shadow-sm">
              <img src={entry.imageUrl} alt="Daily Motivation" className="w-full h-48 object-cover" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                 <button onClick={removeImage} className="bg-white/20 hover:bg-white/40 backdrop-blur-md p-2 rounded-full text-white">
                   <Trash2 size={20} />
                 </button>
              </div>
            </div>
          ) : isCameraOpen ? (
            <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex flex-col items-center justify-center">
               <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover transform -scale-x-100"></video>
               
               <div className="absolute top-2 right-2">
                 <button onClick={stopCamera} className="bg-black/40 text-white p-2 rounded-full backdrop-blur-sm">
                   <X size={20} />
                 </button>
               </div>
               
               <div className="absolute bottom-4 w-full flex justify-center items-center">
                 <button 
                   onClick={capturePhoto} 
                   className="w-16 h-16 rounded-full border-4 border-white bg-white/20 backdrop-blur-sm flex items-center justify-center active:scale-95 transition-transform"
                 >
                   <div className="w-12 h-12 bg-white rounded-full"></div>
                 </button>
               </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 h-24">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-400 hover:border-primary hover:text-primary hover:bg-primary/5 transition-all gap-1"
              >
                <ImageIcon size={20} />
                <span className="text-xs font-medium">Upload File</span>
              </button>
              
              <button 
                onClick={startCamera}
                className="border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-400 hover:border-indigo-500 hover:text-indigo-500 hover:bg-indigo-50 transition-all gap-1"
              >
                <Camera size={20} />
                <span className="text-xs font-medium">Kamera</span>
              </button>
            </div>
          )}
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*"
            onChange={handleImageUpload}
          />
        </div>
        
        {/* Only show Mood selector if not in future */}
        {!isFuture && (
          <div className="animate-in fade-in slide-in-from-top-2 pt-2 border-t border-slate-100/50">
             <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Gimana Perasaanmu di Polibatam Hari Ini?</label>
             <div className="flex justify-between gap-2">
               {(Object.keys(MOOD_EMOJIS) as Mood[]).map((m) => (
                 <button
                  key={m}
                  onClick={() => setEntry({...entry, mood: m})}
                  className={`flex-1 flex flex-col items-center p-2 rounded-xl border transition-all ${entry.mood === m ? 'border-primary bg-indigo-50 ring-2 ring-primary/20' : 'border-slate-100 bg-slate-50 opacity-70 hover:opacity-100'}`}
                 >
                   <span className="text-2xl mb-1">{MOOD_EMOJIS[m]}</span>
                   <span className="text-[10px] font-medium text-slate-600">{MOOD_LABELS[m]}</span>
                 </button>
               ))}
             </div>
          </div>
        )}
      </div>

      {/* Jobdesk / Tasks Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-800">
            {isFuture ? 'Rencana & Target Belajar' : 'Jobdesk & Praktikum'}
          </h3>
          <button 
            onClick={() => setShowBrainDump(!showBrainDump)}
            className="text-xs bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-md shadow-purple-200"
          >
            <Wand2 size={12} /> Magic Plan
          </button>
        </div>

        {/* AI Generator Input */}
        {showBrainDump && (
          <div className="bg-white p-4 rounded-xl border border-purple-100 shadow-sm animate-in fade-in slide-in-from-top-4">
            <textarea
              value={brainDump}
              onChange={(e) => setBrainDump(e.target.value)}
              placeholder={isFuture 
                ? "Besok mau ngapain aja? Contoh: Belajar Algoritma, ngerjain laporan Bengkel IT, olahraga sore."
                : "Tulis apa aja yang harus dikerjakan... Contoh: Deadline tugas C++, rapat himpunan."}
              className="w-full text-sm p-3 bg-slate-50 rounded-lg border-0 focus:ring-2 focus:ring-purple-500 mb-3 h-24 resize-none"
            />
            <div className="flex justify-end">
              <button 
                onClick={handleMagicPlan}
                disabled={loadingAI}
                className="bg-purple-600 text-white text-sm px-4 py-2 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2"
              >
                {loadingAI ? <Loader2 className="animate-spin" size={16}/> : <BrainCircuit size={16} />}
                Generate Jobdesk
              </button>
            </div>
          </div>
        )}

        {/* Task List */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          {entry.tasks.length === 0 ? (
            <div className="p-8 text-center text-slate-400">
              <p className="text-sm">{isFuture ? 'Belum ada rencana.' : 'Belum ada jobdesk.'}</p>
              <button 
                onClick={() => addTask(isFuture ? "Rencana Baru" : "Jobdesk Baru")}
                className="mt-2 text-primary text-sm font-medium hover:underline"
              >
                + Tambah Manual
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {entry.tasks.map((task) => (
                <div key={task.id} className="group flex items-center p-3 hover:bg-slate-50 transition-colors">
                  <button 
                    onClick={() => toggleTaskStatus(task.id)}
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-3 transition-colors ${task.status === TaskStatus.DONE ? 'bg-emerald-500 border-emerald-500 text-white animate-pop' : 'border-slate-300 text-transparent hover:border-emerald-400'}`}
                  >
                    <Check size={14} strokeWidth={3} />
                  </button>
                  <input 
                    type="text" 
                    value={task.title}
                    onChange={(e) => {
                      const newTitle = e.target.value;
                      setEntry(prev => ({
                        ...prev,
                        tasks: prev.tasks.map(t => t.id === task.id ? { ...t, title: newTitle } : t)
                      }));
                    }}
                    className={`flex-1 bg-transparent border-none focus:ring-0 p-0 text-slate-700 transition-all duration-300 ${task.status === TaskStatus.DONE ? 'line-through text-slate-400' : ''}`}
                  />
                  <button 
                    onClick={() => removeTask(task.id)}
                    className="text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity px-2"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {/* Add Manual Task Button */}
          <div className="bg-slate-50 p-3 border-t border-slate-100">
            <button 
              onClick={() => addTask("")}
              className="flex items-center gap-2 text-slate-500 hover:text-primary transition-colors text-sm font-medium w-full"
            >
              <Plus size={16} /> {isFuture ? 'Tambah Rencana' : 'Tambah Jobdesk'}
            </button>
          </div>
        </div>
      </div>

      {/* Notes, Achievements & Reflection - Only full functionality if not future */}
      <div className="space-y-4">
        {/* Curhat */}
        <div className="space-y-2">
          <h3 className="text-lg font-bold text-slate-800">
            {isFuture ? 'Catatan Persiapan' : 'Curhat ke Mamak'}
          </h3>
          <textarea 
            value={entry.notes}
            onChange={(e) => setEntry({...entry, notes: e.target.value})}
            placeholder={isFuture 
              ? "Catatan penting untuk hari tersebut... (Misal: Jangan lupa bawa KTM)" 
              : "Ada hal menarik apa hari ini di kampus? Dosennya gimana? Praktikum lancar?"}
            className="w-full bg-white p-4 rounded-2xl border border-slate-100 shadow-sm focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all h-24 resize-none"
          />
        </div>

        {/* Pencapaian (Achievements) - New Section */}
        {!isFuture && (
           <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
             <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <Trophy size={20} className="text-amber-500" />
               Pencapaian Hari Ini
             </h3>
             <textarea 
               value={entry.achievements || ''}
               onChange={(e) => setEntry({...entry, achievements: e.target.value})}
               placeholder="Tulis hal kecil yang berhasil kamu lakukan! (Contoh: Berhasil compile code tanpa error, datang tepat waktu, paham materi pointer)"
               className="w-full bg-amber-50 p-4 rounded-2xl border border-amber-100 shadow-sm focus:ring-2 focus:ring-amber-500/20 focus:border-amber-400 transition-all h-24 resize-none text-amber-900 placeholder:text-amber-900/40"
             />
           </div>
        )}
      </div>

      {/* AI Review & Call Section - Hide if Future */}
      {!isNew && !isFuture && (
        <div className="pt-4 border-t border-slate-200 animate-in fade-in space-y-4">
          
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <span className="text-xl">👩‍🦳</span> Kata Mamak
            </h3>
            
            {/* Call Button */}
            <button
               onClick={startCall}
               className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-md shadow-indigo-200 transition-all active:scale-95"
            >
              <Phone size={12} /> Telpon Mamak
            </button>
          </div>
          
          {loadingAI && !entry.aiSummary ? (
            <div className="p-4 bg-slate-100 rounded-xl animate-pulse flex justify-center">
              <Loader2 className="animate-spin text-slate-400" />
            </div>
          ) : (
            <div className={`p-5 rounded-2xl border ${entry.aiSummary ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-slate-100 text-slate-500 border-dashed text-center'}`}>
              {entry.aiSummary ? (
                <div className="space-y-3">
                  <p className="italic font-medium leading-relaxed">"{entry.aiSummary}"</p>
                  <div className="flex justify-end">
                     <button onClick={handleMagicReview} className="text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded text-white flex items-center gap-1">
                        <BrainCircuit size={10} /> Buat Ulang
                     </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                   <p className="text-sm">Selesaikan tugas & tulis pencapaian dulu Nak, baru lapor ke Mamak.</p>
                   <button onClick={handleMagicReview} className="text-primary text-sm font-bold hover:underline">
                      Minta Pendapat Mamak
                   </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      <div ref={scrollRef}></div>
    </div>
  );
};