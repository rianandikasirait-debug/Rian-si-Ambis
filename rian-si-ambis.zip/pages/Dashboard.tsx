import React, { useEffect, useState } from 'react';
import { Plus, Calendar, CheckCircle2, Circle, Bell, Clock, CalendarDays, AlertCircle, Image as ImageIcon } from 'lucide-react';
import { getEntries } from '../services/storageService';
import { DailyEntry, MOOD_EMOJIS, TaskStatus, Mood } from '../types';
import { useNavigate } from '../App';

const calculateProgress = (entry: DailyEntry) => {
  if (!entry.tasks || entry.tasks.length === 0) return 0;
  const done = entry.tasks.filter(t => t.status === TaskStatus.DONE).length;
  return Math.round((done / entry.tasks.length) * 100);
};

const formatDate = (dateStr: string) => {
  return new Date(dateStr).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
};

interface EntryCardProps {
  entry: DailyEntry;
  isUpcoming?: boolean;
  onClick: () => void;
}

const EntryCard: React.FC<EntryCardProps> = ({ entry, isUpcoming = false, onClick }) => {
  const progress = calculateProgress(entry);
  const isFull = progress === 100 && entry.tasks.length > 0;
  
  return (
    <div 
      onClick={onClick}
      className={`p-5 rounded-2xl border transition-all cursor-pointer group relative overflow-hidden ${isUpcoming ? 'bg-indigo-50 border-indigo-100 hover:border-indigo-300' : 'bg-white border-slate-100 shadow-sm hover:shadow-md'}`}
    >
      <div className="flex justify-between items-start mb-3 relative z-10">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h4 className={`font-bold text-lg ${isUpcoming ? 'text-indigo-900' : 'text-slate-800'}`}>
              {formatDate(entry.date)}
            </h4>
            {/* Only show mood if it's history/today and set */}
            {!isUpcoming && MOOD_EMOJIS[entry.mood] && entry.mood !== Mood.NEUTRAL && (
              <span className="text-xl" title="Mood">{MOOD_EMOJIS[entry.mood]}</span>
            )}
          </div>
          <p className="text-slate-500 text-sm line-clamp-1 mt-1 pr-2">
            {entry.notes || (isUpcoming ? "Rencana belum ada catatan." : "Tidak ada catatan tambahan.")}
          </p>
        </div>
        <div className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap ${isFull ? 'bg-emerald-100 text-emerald-700' : isUpcoming ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'}`}>
          {isUpcoming ? `${entry.tasks.length} Rencana` : `${progress}% Selesai`}
        </div>
      </div>

      {/* Thumbnail Image if exists */}
      {entry.imageUrl && (
        <div className="mb-3 relative z-10">
          <div className="h-24 w-full rounded-lg overflow-hidden bg-slate-200 relative">
             <img src={entry.imageUrl} alt="Thumbnail" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
             <div className="absolute top-1 right-1 bg-black/50 text-white text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
               <ImageIcon size={10} /> Foto
             </div>
          </div>
        </div>
      )}

      {/* Progress Bar only for History */}
      {!isUpcoming && (
        <div className="w-full bg-slate-100 rounded-full h-2 mb-4 relative z-10">
          <div 
            className={`h-2 rounded-full transition-all duration-500 ${isFull ? 'bg-emerald-500' : 'bg-primary'}`}
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      )}

      {/* Mini Task Preview (Max 3) */}
      <div className="space-y-2 relative z-10">
        {entry.tasks.slice(0, 3).map((task) => (
          <div key={task.id} className="flex items-center gap-2 text-sm text-slate-600">
            {task.status === TaskStatus.DONE ? (
              <CheckCircle2 size={14} className="text-emerald-500" />
            ) : (
              <Circle size={14} className={isUpcoming ? "text-indigo-300" : "text-slate-300"} />
            )}
            <span className={`line-clamp-1 ${task.status === TaskStatus.DONE ? 'line-through text-slate-400' : ''}`}>
              {task.title}
            </span>
          </div>
        ))}
        {entry.tasks.length > 3 && (
          <p className="text-xs text-slate-400 pl-6">+ {entry.tasks.length - 3} jobdesk lainnya</p>
        )}
      </div>
    </div>
  );
};

interface Reminder {
  daysLeft: number;
  entry: DailyEntry;
}

export const Dashboard: React.FC = () => {
  const [upcomingEntries, setUpcomingEntries] = useState<DailyEntry[]>([]);
  const [historyEntries, setHistoryEntries] = useState<DailyEntry[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  
  const { navigate } = useNavigate();

  useEffect(() => {
    const allEntries = getEntries();

    const todayStr = new Date().toISOString().split('T')[0];
    const todayDate = new Date(todayStr);
    
    // Separate Future vs History
    const upcoming = allEntries.filter(e => e.date > todayStr).sort((a, b) => a.date.localeCompare(b.date));
    const history = allEntries.filter(e => e.date <= todayStr);

    setUpcomingEntries(upcoming);
    setHistoryEntries(history);

    // Calculate Notifications (1, 2, 3 days left)
    const activeReminders: Reminder[] = [];
    
    upcoming.forEach(entry => {
      const entryDate = new Date(entry.date);
      // Diff in ms
      const diffTime = entryDate.getTime() - todayDate.getTime();
      // Diff in days (ceil ensures that if it's currently Day 0 evening and target is Day 2 morning, it counts correctly as approx 2 days)
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays >= 1 && diffDays <= 3) {
        activeReminders.push({ daysLeft: diffDays, entry });
      }
    });

    setReminders(activeReminders);

    // Browser Notification Request
    if (activeReminders.length > 0 && "Notification" in window && Notification.permission !== "granted") {
      Notification.requestPermission();
    }
  }, []);

  const createNewEntry = (isFuture: boolean = false) => {
    const today = new Date().toISOString().split('T')[0];
    let initialDate = today;

    if (isFuture) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      initialDate = tomorrow.toISOString().split('T')[0];
    }

    const newId = crypto.randomUUID();
    navigate('entry', { id: newId, date: initialDate, isNew: true });
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Horas, Mahasiswa! 👋</h2>
          <p className="text-slate-500">Mamak pantau dari sini ya.</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <button
            onClick={() => createNewEntry(true)}
            className="flex-1 sm:flex-none bg-white hover:bg-slate-50 text-indigo-600 border border-indigo-200 px-4 py-2 rounded-xl transition-all flex items-center justify-center gap-2 font-medium active:scale-95"
          >
            <CalendarDays size={18} />
            Rencanakan
          </button>
          <button
            onClick={() => createNewEntry(false)}
            className="flex-1 sm:flex-none bg-primary hover:bg-indigo-700 text-white px-4 py-2 rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 font-medium active:scale-95"
          >
            <Plus size={18} />
            Catatan Hari Ini
          </button>
        </div>
      </div>

      {/* Notifications Banner */}
      {reminders.length > 0 && (
        <div className="space-y-2">
          {reminders.map((rem, idx) => (
            <div 
              key={`${rem.entry.id}-rem-${idx}`}
              onClick={() => navigate('entry', { id: rem.entry.id })}
              className={`rounded-2xl p-4 text-white shadow-lg cursor-pointer transition-transform hover:scale-[1.01] flex items-start gap-3 ${
                rem.daysLeft === 1 ? 'bg-gradient-to-r from-rose-500 to-red-500 shadow-rose-200' :
                rem.daysLeft === 2 ? 'bg-gradient-to-r from-orange-500 to-amber-500 shadow-orange-200' :
                'bg-gradient-to-r from-indigo-500 to-blue-500 shadow-indigo-200'
              }`}
            >
              <div className="bg-white/20 p-2 rounded-lg shrink-0">
                <AlertCircle size={20} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg">
                  {rem.daysLeft === 1 ? '⚠️ BESOK TUH!' : 
                   rem.daysLeft === 2 ? '⚠️ 2 Hari Lagi Nak!' : 
                   '🔔 3 Hari Lagi, Siap-siap!'}
                </h3>
                <p className="text-white/90 text-sm">
                  Jangan lupa agenda: <strong>{formatDate(rem.entry.date)}</strong>
                </p>
                <div className="mt-1 text-xs bg-white/20 inline-block px-2 py-0.5 rounded-lg">
                  {rem.entry.tasks.length} Rencana perlu disiapkan
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upcoming Plans Section */}
      {upcomingEntries.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-indigo-900 flex items-center gap-2">
            <Clock size={18} className="text-indigo-500" />
            Rencana Mendatang
          </h3>
          <div className="grid gap-4">
            {upcomingEntries.map(entry => (
              <EntryCard 
                key={entry.id} 
                entry={entry} 
                isUpcoming={true} 
                onClick={() => navigate('entry', { id: entry.id })}
              />
            ))}
          </div>
        </div>
      )}

      {/* Entries List */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <Calendar size={18} className="text-slate-400" />
          Riwayat Jurnal
        </h3>
        
        {historyEntries.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
            <p className="text-slate-400">Belum ada catatan. Mulai tulis biar Mamak senang.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {historyEntries.map(entry => (
              <EntryCard 
                key={entry.id} 
                entry={entry}
                onClick={() => navigate('entry', { id: entry.id })}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};